/**
 * Popup license/trial gate. Runs after popup.js. Reads TTVLicense.state():
 *   active → nothing shown. trial → a banner with the request token.
 *   locked → a full-cover activation card (key field + token + Instagram hint).
 * Activating reloads the popup so everything re-initialises unlocked.
 */
(() => {
  'use strict';
  const byId = (id) => document.getElementById(id);

  async function currentLang() {
    try {
      const { profile } = await api.storage.local.get('profile');
      if (profile && typeof profile === 'object') {
        const store = (typeof migrateStore === 'function') ? migrateStore(profile) : profile;
        return (store.settings && store.settings.language) || 'en';
      }
    } catch { /* locked/encrypted — fall back */ }
    return 'en';
  }

  async function activate() {
    const key = byId('licKey').value.trim();
    const err = byId('licErr');
    err.hidden = true;
    if (!key) return;
    const res = await window.TTVLicense.activate(key);
    if (res.ok) { location.reload(); return; }
    err.hidden = false;
    err.textContent = res.reason === 'expired' ? t('license.expired') : t('license.invalid');
  }

  function showGate(token, closable) {
    // A close affordance only when opened voluntarily during the trial; when the
    // trial has truly lapsed the gate is a hard stop (no close).
    let x = byId('licClose');
    if (closable) {
      if (!x) {
        x = document.createElement('button');
        x.id = 'licClose'; x.className = 'icon-btn lic-close'; x.type = 'button'; x.textContent = '×';
        x.title = 'Close';
        byId('license').querySelector('.lic-card').prepend(x);
      }
      x.hidden = false;
      x.onclick = () => { byId('license').hidden = true; };
    } else if (x) { x.hidden = true; }
    byId('licTitle').textContent = t('license.lockTitle');
    byId('licSub').textContent = t('license.lockSub');
    byId('licRead').textContent = t('license.read');
    // No token flow — the user simply messages us on Instagram for a key.
    byId('licTokenLabel').style.display = 'none';
    byId('licToken').parentElement.style.display = 'none'; // the token + copy row
    byId('licTokenHelp').textContent = t('license.tokenHelp');
    byId('licKey').placeholder = t('license.keyPlaceholder');
    byId('licActivate').textContent = t('license.activate');
    byId('licGetKey').textContent = t('license.getKey') + ' ↗';
    byId('licGetKey').href = 'https://www.instagram.com/tirumalatirupativlogs/';
    byId('licFoot').textContent = t('license.offline');
    byId('license').hidden = false;

    byId('licActivate').onclick = activate;
    byId('licKey').addEventListener('keydown', (e) => { if (e.key === 'Enter') activate(); });
  }

  function showTrial(token, daysLeft) {
    const bar = byId('licenseTrial');
    bar.hidden = false; bar.innerHTML = '';
    const msg = document.createElement('span');
    msg.textContent = t('license.trialBanner').replace('{n}', daysLeft).replace('{tok}', token);
    const link = document.createElement('a');
    link.href = 'https://www.tirumalainfo.com/chrome';
    link.target = '_blank'; link.rel = 'noopener noreferrer';
    link.className = 'lic-trial-link';
    link.textContent = t('license.trialGetKey') + ' ↗';
    const enter = document.createElement('button');
    enter.type = 'button'; enter.className = 'lic-trial-enter';
    enter.textContent = t('license.activate');
    enter.onclick = () => showGate(token, true);
    bar.append(msg, document.createTextNode(' '), link, document.createTextNode(' · '), enter);
  }

  async function run() {
    if (!window.TTVLicense) return;
    try { setLang(await currentLang()); } catch { /* */ }
    const s = await window.TTVLicense.state();
    const portal = byId('portalNote');
    if (s.status === 'active') {
      // Activated member: no trial banner, no gate — and drop the public
      // disclaimer too (they've read it and are past the gate).
      byId('licenseTrial').hidden = true;
      byId('license').hidden = true;
      if (portal) portal.hidden = true;
      return;
    }
    if (portal) portal.hidden = false; // trial / locked → keep the disclaimer visible
    if (s.status === 'trial') { byId('license').hidden = true; showTrial(s.token, s.daysLeft); return; }
    byId('licenseTrial').hidden = true;
    showGate(s.token, false);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
