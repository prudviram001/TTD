/**
 * License + trial gate (offline, privacy-preserving).
 *
 * The extension is fully usable for a 7-day TRIAL from first run — so reviewers
 * and new users are never hard-walled. After that a free, request-based KEY is
 * needed: the user DMs the short token this install shows to the project's
 * Instagram, gets a key minted for that token, and pastes it here.
 *
 * Keys are verified ENTIRELY ON-DEVICE with an embedded ECDSA P-256 public key —
 * nothing is sent anywhere, and no server is contacted. A key is signed by the
 * project's private key (kept off the web), so it cannot be forged; it is bound
 * to this install's token (tok), so it cannot be mass-shared. A wildcard token
 * ("*") unlocks any install — that is the reviewer key, never shared publicly.
 *
 * Shared by the popup and the content script (both load api.js first for
 * api.storage). It only ever reads/writes local storage and verifies a string.
 */
(() => {
  'use strict';

  // The PROJECT public key. Safe to be public. Replace with your own before
  // publishing (see LICENSE-SETUP.md) so only you can mint keys. (dev keypair)
  // The production public key. (self.__TTV_PUBKEY is an override used ONLY by the
  // offline test harness — a web page cannot set it, since content scripts run in
  // an isolated world the page can't reach.)
  const PUBKEY_JWK = (typeof globalThis !== 'undefined' && globalThis.__TTV_PUBKEY) ? globalThis.__TTV_PUBKEY : {
    kty: 'EC', crv: 'P-256',
    x: 'vfsZr8-pyJTw2uA7QUFYqrMC0eq5_Wze6_2w3xFccqE',
    y: '4oYGz4ykKtXvDoBs_PuqixuK9UGHVzRHfAqu5KT4vcQ',
  };
  const TRIAL_DAYS = 7;
  const TRIAL_MS = TRIAL_DAYS * 24 * 60 * 60 * 1000;
  const K = { INSTALL: 'ttvInstallAt', TOKEN: 'ttvToken', LICENSE: 'ttvLicense' };

  const sget = async (keys) => { try { return await api.storage.local.get(keys); } catch { return {}; } };
  const sset = async (obj) => { try { return await api.storage.local.set(obj); } catch { /* */ } };

  const b64url = (s) => {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(s); const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  };
  const enc = new TextEncoder();

  let _key = null;
  async function pubkey() {
    if (_key) return _key;
    _key = await crypto.subtle.importKey('jwk', PUBKEY_JWK, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    return _key;
  }

  // Short, DM-friendly token for THIS install, e.g. "TTV-7K3P-9QX2". Unambiguous
  // alphabet (no 0/O/1/I/L). Generated once and kept.
  function newToken() {
    const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    const r = crypto.getRandomValues(new Uint8Array(8));
    let s = ''; for (const b of r) s += A[b % A.length];
    return 'TTV-' + s.slice(0, 4) + '-' + s.slice(4, 8);
  }
  async function token() {
    const r = await sget(K.TOKEN);
    if (r[K.TOKEN]) return r[K.TOKEN];
    const t = newToken();
    await sset({ [K.TOKEN]: t });
    return t;
  }

  async function installAt() {
    const r = await sget(K.INSTALL);
    if (r[K.INSTALL]) return r[K.INSTALL];
    const now = Date.now();
    await sset({ [K.INSTALL]: now });
    return now;
  }

  // Verify a pasted key against the embedded public key and this install's token.
  async function verify(keyStr, tok) {
    try {
      const parts = String(keyStr || '').trim().split('.');
      if (parts.length !== 3 || parts[0] !== 'TTV1') return { ok: false, reason: 'format' };
      const good = await crypto.subtle.verify(
        { name: 'ECDSA', hash: 'SHA-256' }, await pubkey(), b64url(parts[2]), enc.encode(parts[1]));
      if (!good) return { ok: false, reason: 'signature' };
      const payload = JSON.parse(new TextDecoder().decode(b64url(parts[1])));
      if (payload.exp && payload.exp > 0 && payload.exp * 1000 < Date.now()) return { ok: false, reason: 'expired' };
      if (payload.tok !== '*' && payload.tok !== tok) return { ok: false, reason: 'token' };
      return { ok: true, payload };
    } catch { return { ok: false, reason: 'error' }; }
  }

  async function activate(keyStr) {
    const res = await verify(keyStr, await token());
    if (res.ok) await sset({ [K.LICENSE]: String(keyStr).trim() });
    return res;
  }
  async function deactivate() { await sset({ [K.LICENSE]: '' }); }

  /**
   * The gate's view of the world:
   *   { status: 'active' | 'trial' | 'locked', token, daysLeft?, payload? }
   */
  async function state() {
    const tok = await token();
    const r = await sget([K.LICENSE, K.INSTALL]);
    if (r[K.LICENSE]) {
      const res = await verify(r[K.LICENSE], tok);
      if (res.ok) return { status: 'active', token: tok, payload: res.payload };
    }
    const inst = r[K.INSTALL] || await installAt();
    const left = TRIAL_MS - (Date.now() - inst);
    if (left > 0) return { status: 'trial', token: tok, daysLeft: Math.max(1, Math.ceil(left / 86400000)) };
    return { status: 'locked', token: tok };
  }

  // May the fill / paste features run right now? (trial or activated)
  async function allowed() {
    const s = await state();
    return s.status === 'trial' || s.status === 'active';
  }

  // Start the trial clock as early as possible, not only on first gate check.
  installAt();

  const API = { state, allowed, activate, deactivate, verify, token, TRIAL_DAYS };
  if (typeof window !== 'undefined') window.TTVLicense = API;
  if (typeof module !== 'undefined') module.exports = API;
})();
